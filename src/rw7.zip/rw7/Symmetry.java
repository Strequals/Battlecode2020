package rw7;

public enum Symmetry {
	HORIZONTAL, VERTICAL, ROTATIONAL

}
