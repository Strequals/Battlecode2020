package rw1;

import battlecode.common.*;

public class Communications {
	
	public static void sendMessage(RobotController rc) {
		
	}

}
