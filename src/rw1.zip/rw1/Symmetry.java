package rw1;

public enum Symmetry {
	HORIZONTAL, VERTICAL, ROTATIONAL

}
