package rw1;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public strictfp class NetGunRobot extends Robot {

	public NetGunRobot(RobotController rc) throws GameActionException {
		super(rc);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() throws GameActionException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void processMessage(int m, int x, int y) {
		// TODO Auto-generated method stub
		
	}

}
