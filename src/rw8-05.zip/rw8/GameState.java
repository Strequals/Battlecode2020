package rw8;

import battlecode.common.*;

public class GameState {
	
	RobotInfo[] nearbyRobots;
	int round;
	MapLocation location;
	int senseRadiusSq;

}
