package rw5;

public enum Symmetry {
	HORIZONTAL, VERTICAL, ROTATIONAL

}
